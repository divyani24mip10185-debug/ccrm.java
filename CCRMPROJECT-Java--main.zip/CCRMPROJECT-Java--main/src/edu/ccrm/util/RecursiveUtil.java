package edu.ccrm.util;

import java.nio.file.Path;

public class RecursiveUtil {

	public static long totalSize(Path snapshot) {
		// TODO Auto-generated method stub
		return 0;
	}

}
