package java.nio.files;

public record Files() {

}
